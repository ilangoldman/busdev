import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { ViewChild } from '@angular/core';
import { Slides } from 'ionic-angular';

@Component({
  selector: 'page-set-up',
  templateUrl: 'set-up.html',
})
export class SetUpPage {
  @ViewChild(Slides) slides: Slides;
  @ViewChild('second') slides2: Slides;

  slidesBD = [
    {
      title: "Welcome to the BusDev App!",
      description: "The <b>Development</b> for <b>Business Man</b>!.",
      image: "assets/img/busdev.png",
      setRadio: false,
      setButton: false,
      buttonText: "OK",
      buttonIcon: "arrow-forward",
      shouldLockSwipeToNext: true
    },
    {
      title: "Choose you Navigation Style",
      description: "sdfv",
      image: "assets/img/",
      setRadio: true,
      setButton: true,
      buttonText: "Continue",
      buttonIcon: "arrow-forward",
      shouldLockSwipeToNext: false
    },
    {
      title: "Choose your Main Page",
      description: "",
      image: "assets/img/",
      setRadio: false,
      setButton: true,
      buttonText: "Continue",
      buttonIcon: "arrow-forward",
      shouldLockSwipeToNext: true
    },
    {
      title: "Choose your Main Page",
      description: "211",
      image: "assets/img/",
      setRadio: true,
      setButton: true,
      buttonText: "Continue",
      buttonIcon: "arrow-forward",
      shouldLockSwipeToNext: true
    }
  ];

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SetUpPage');
  }

  allowChange() {
    console.log(this.slides.getActiveIndex());
    console.log(this.slidesBD[this.slides.getActiveIndex()].title);
    console.log(this.slidesBD[this.slides.getActiveIndex()].shouldLockSwipeToNext);
    //this.slides.lockSwipeToNext(this.slidesBD[this.slides.getActiveIndex()].shouldLockSwipeToNext);
  }

  next() {
    this.slides.lockSwipeToNext(false);
    this.slides.slideNext();
  }
}
